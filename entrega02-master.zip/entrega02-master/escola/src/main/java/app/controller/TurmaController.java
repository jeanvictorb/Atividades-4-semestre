package app.controller;

import app.entity.Turma;
import app.service.TurmaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/turmas")
public class TurmaController {

    @Autowired
    private TurmaService turmaService;

    @PostMapping
    public Turma criarTurma(@RequestBody Turma turma) {
        return turmaService.salvarTurma(turma);
    }

    @GetMapping
    public List<Turma> listarTurmas() {
        return turmaService.buscarTodos();
    }

    @GetMapping("/{id}")
    public Turma buscarTurma(@PathVariable Long id) {
        return turmaService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Turma atualizarTurma(@PathVariable Long id, @RequestBody Turma turma) {
        turma.setId(id);
        return turmaService.atualizarTurma(turma);
    }

    @DeleteMapping("/{id}")
    public void excluirTurma(@PathVariable Long id) {
        turmaService.excluirTurma(id);
    }

    @GetMapping("/filtro/ano")
    public List<Turma> buscarPorAnoEntre(@RequestParam int anoInicio, @RequestParam int anoFim) {
        return turmaService.buscarPorAnoEntre(anoInicio, anoFim);
    }

    @GetMapping("/filtro/semestre")
    public List<Turma> buscarPorSemestreEAno(@RequestParam String semestre, @RequestParam int ano) {
        return turmaService.buscarPorSemestreEAno(semestre, ano);
    }

    @GetMapping("/filtro/nome-e-turno")
    public List<Turma> buscarPorNomeETurno(@RequestParam String nome, @RequestParam String turno) {
        return turmaService.buscarPorNomeETurno(nome, turno);
    }

    @GetMapping("/filtro/curso")
    public List<Turma> buscarPorCurso(@RequestParam String nomeCurso) {
        return turmaService.buscarPorCurso(nomeCurso);
    }
}
