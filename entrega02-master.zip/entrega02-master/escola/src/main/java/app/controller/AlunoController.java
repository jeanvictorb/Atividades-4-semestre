package app.controller;

import app.entity.Aluno;
import app.service.AlunoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alunos")
public class AlunoController {

    @Autowired
    private AlunoService alunoService;

    @PostMapping
    public Aluno criarAluno(@RequestBody Aluno aluno) {
        return alunoService.salvarAluno(aluno);
    }

    @GetMapping
    public List<Aluno> listarAlunos() {
        return alunoService.buscarTodos();
    }

    @GetMapping("/{id}")
    public Aluno buscarAluno(@PathVariable Long id) {
        return alunoService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Aluno atualizarAluno(@PathVariable Long id, @RequestBody Aluno aluno) {
        aluno.setId(id);
        return alunoService.atualizarAluno(aluno);
    }

    @DeleteMapping("/{id}")
    public void excluirAluno(@PathVariable Long id) {
        alunoService.excluirAluno(id);
    }

    @GetMapping("/filtro/nome/{nome}")
    public List<Aluno> buscarPorNome(@PathVariable String nome) {
        return alunoService.buscarPorNome(nome);
    }

    @GetMapping("/filtro/telefone/{telefone}")
    public List<Aluno> buscarPorTelefone(@PathVariable String telefone) {
        return alunoService.buscarPorTelefone(telefone);
    }

    @GetMapping("/filtro/turma/{turma}")
    public List<Aluno> buscarPorTurma(@PathVariable String turma) {
        return alunoService.buscarPorTurma(turma);
    }
}
