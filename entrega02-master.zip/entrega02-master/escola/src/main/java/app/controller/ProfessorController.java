package app.controller;

import app.entity.Professor;
import app.service.ProfessorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/professores")
public class ProfessorController {

    @Autowired
    private ProfessorService professorService;

    @PostMapping
    public Professor criarProfessor(@RequestBody Professor professor) {
        return professorService.salvarProfessor(professor);
    }

    @GetMapping
    public List<Professor> listarProfessores() {
        return professorService.buscarTodos();
    }

    @GetMapping("/{id}")
    public Professor buscarProfessor(@PathVariable Long id) {
        return professorService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Professor atualizarProfessor(@PathVariable Long id, @RequestBody Professor professor) {
        professor.setId(id);
        return professorService.atualizarProfessor(professor);
    }

    @DeleteMapping("/{id}")
    public void excluirProfessor(@PathVariable Long id) {
        professorService.excluirProfessor(id);
    }

    @GetMapping("/filtro/nome-ou-especialidade")
    public List<Professor> buscarPorNomeOuEspecialidade(@RequestParam String nome, @RequestParam String especialidade) {
        return professorService.buscarPorNomeOuEspecialidade(nome, especialidade);
    }

    @GetMapping("/filtro/email")
    public List<Professor> buscarPorEmail(@RequestParam String email) {
        return professorService.buscarPorEmailExato(email);
    }

    @GetMapping("/filtro/email-nao-gmail")
    public List<Professor> buscarPorEmailNaoGmail() {
        return professorService.buscarPorEmailNaoGmail();
    }
}
