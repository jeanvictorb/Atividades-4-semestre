package app.controller;

import app.entity.Curso;
import app.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cursos")
public class CursoController {

    @Autowired
    private CursoService cursoService;

    @PostMapping
    public Curso criarCurso(@RequestBody Curso curso) {
        return cursoService.salvarCurso(curso);
    }

    @GetMapping
    public List<Curso> listarCursos() {
        return cursoService.buscarTodos();
    }

    @GetMapping("/{id}")
    public Curso buscarCurso(@PathVariable Long id) {
        return cursoService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Curso atualizarCurso(@PathVariable Long id, @RequestBody Curso curso) {
        curso.setId(id);
        return cursoService.atualizarCurso(curso);
    }

    @DeleteMapping("/{id}")
    public void excluirCurso(@PathVariable Long id) {
        cursoService.excluirCurso(id);
    }

    @GetMapping("/filtro/nome")
    public List<Curso> buscarPorNome(@RequestParam String nome) {
        return cursoService.buscarPorNome(nome);
    }
}
