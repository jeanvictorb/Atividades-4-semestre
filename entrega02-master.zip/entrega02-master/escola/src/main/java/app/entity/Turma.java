package app.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Turma {

	@Id
	private long id;

	@NotBlank(message = "O nome da turma é um campo obrigatório")
	private String nome;

	private String semestre; 
	
	private int ano;
	
	private String turno;
	
	@ManyToMany
	@JoinTable(name="turma_abc_professor")
	@JsonIgnoreProperties("turmas")
	@NotEmpty(message = "Não é possível existir uam turma sem pelo menos um professor associado")
	private List<Professor> professores;
	
	@OneToMany(mappedBy = "turma")
	@JsonIgnoreProperties()
	private List<Aluno> alunos;
	
	@ManyToOne
	@NotNull(message = "O curso é obrigatório para salvar uma turma")
	private Curso curso;
}
