package app.entity;

import org.hibernate.validator.constraints.br.CPF;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Aluno {
	
	@Id
	private long id;
	
	@NotBlank(message="O campo nome do aluno é obrigatório")
	@Pattern(regexp = "\\S+\\s+\\S+.*$", message = "O nome deve conter duas palavras")
	private String nome;
	
	@CPF(message = "o CPF deve ser válido")
	//@Pattern(regexp = "([0-9]{2}[\\.]?[0-9]{3}[\\.]?[0-9]{3}[\\/]?[0-9]{4}[-]?[0-9]{2})|([0-9]{3}[\\.]?[0-9]{3}[\\.]?[0-9]{3}[-]?[0-9]{2})")
	private String cpf;
	
	private String telefone;
	
	@ManyToOne
	@JsonIgnoreProperties("alunos")
	private Turma turma;
	
	

}
