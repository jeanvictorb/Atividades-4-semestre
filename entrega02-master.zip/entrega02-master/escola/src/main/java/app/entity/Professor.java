package app.entity;

import java.util.List;

import org.hibernate.validator.constraints.br.CPF;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Professor {
	
	@Id
	private long id;
	
	@NotBlank(message="O campo nome do aluno é obrigatório")
	@Pattern(regexp = "\\S+\\s+\\S+.*$")
	private String nome;
	
	@CPF(message = "o CPF deve ser válido")
	private String cpf;
	
	@Email(message = "O e-mail deve ser válido")
	private String email;
	
	@Pattern(regexp = "\\S+\\s+\\S+.*$", message = "O nome deve conter duas palavras")
	private String especialidade;
	
	@ManyToMany(mappedBy = "professores")
	@JsonIgnoreProperties("professores")
	private List<Turma> turmas;
}
