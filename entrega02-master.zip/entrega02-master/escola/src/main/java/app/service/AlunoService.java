package app.service;

import app.entity.Aluno;
import app.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlunoService {

    @Autowired
    private AlunoRepository alunoRepository;

    public Aluno salvarAluno(Aluno aluno) {
        if (alunoRepository.existsByCpf(aluno.getCpf())) {
            throw new RuntimeException("CPF já cadastrado!");
        }

        return alunoRepository.save(aluno);
    }

    public List<Aluno> buscarTodos() {
        return alunoRepository.findAll();
    }

    public Aluno buscarPorId(Long id) {
        Optional<Aluno> aluno = alunoRepository.findById(id);
        if (aluno.isEmpty()) {
            throw new RuntimeException("Aluno não encontrado!");
        }
        return aluno.get();
    }

    public Aluno atualizarAluno(Aluno aluno) {
        return salvarAluno(aluno);
    }

    public void excluirAluno(Long id) {
        if (!alunoRepository.existsById(id)) {
            throw new RuntimeException("Aluno não encontrado para exclusão!");
        }
        alunoRepository.deleteById(id);
    }

    public List<Aluno> buscarPorNome(String nome) {
        return alunoRepository.findByNomeStartingWith(nome);
    }

    public List<Aluno> buscarPorTelefone(String telefone) {
        return alunoRepository.findByTelefoneContaining(telefone);
    }

    public List<Aluno> buscarPorTurma(String turma) {
        return alunoRepository.findByTurmaNome(turma);
    }
}
