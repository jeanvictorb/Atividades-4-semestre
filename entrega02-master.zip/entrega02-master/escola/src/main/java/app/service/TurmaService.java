package app.service;

import app.entity.Turma;
import app.repository.TurmaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TurmaService {

    @Autowired
    private TurmaRepository turmaRepository;

    public Turma salvarTurma(Turma turma) {
        return turmaRepository.save(turma);
    }

    public List<Turma> buscarTodos() {
        return turmaRepository.findAll();
    }

    public Turma buscarPorId(Long id) {
        Optional<Turma> turma = turmaRepository.findById(id);
        if (turma.isEmpty()) {
            throw new RuntimeException("Turma não encontrada!");
        }
        return turma.get();
    }

    public Turma atualizarTurma(Turma turma) {
        return salvarTurma(turma);
    }

    public void excluirTurma(Long id) {
        if (!turmaRepository.existsById(id)) {
            throw new RuntimeException("Turma não encontrada para exclusão!");
        }
        turmaRepository.deleteById(id);
    }

    public List<Turma> buscarPorAnoEntre(int anoInicio, int anoFim) {
        return turmaRepository.findByAnoBetween(anoInicio, anoFim);
    }

    public List<Turma> buscarPorSemestreEAno(String semestre, int ano) {
        return turmaRepository.findBySemestreAndAno(semestre, ano);
    }

    public List<Turma> buscarPorNomeETurno(String nome, String turno) {
        return turmaRepository.findByNomeAndTurno(nome, turno);
    }

    public List<Turma> buscarPorCurso(String nomeCurso) {
        return turmaRepository.findByCursoNome(nomeCurso);
    }
}
