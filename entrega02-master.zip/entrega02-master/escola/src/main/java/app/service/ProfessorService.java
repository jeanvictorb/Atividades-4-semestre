package app.service;

import app.entity.Professor;
import app.repository.ProfessorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfessorService {

    @Autowired
    private ProfessorRepository professorRepository;

    public Professor salvarProfessor(Professor professor) {
        if (professorRepository.existsByEmail(professor.getEmail())) {
            throw new RuntimeException("Email já cadastrado!");
        }

        if (professor.getEmail().contains("@outlook.com")) {
            throw new RuntimeException("Domínio de e-mail não permitido");
        }
        
        return professorRepository.save(professor);
    }

    public List<Professor> buscarTodos() {
        return professorRepository.findAll();
    }

    public Professor buscarPorId(Long id) {
        Optional<Professor> professor = professorRepository.findById(id);
        if (professor.isEmpty()) {
            throw new RuntimeException("Professor não encontrado!");
        }
        return professor.get();
    }

    public Professor atualizarProfessor(Professor professor) {
        return salvarProfessor(professor);
    }

    public void excluirProfessor(Long id) {
        if (!professorRepository.existsById(id)) {
            throw new RuntimeException("Professor não encontrado para exclusão!");
        }
        professorRepository.deleteById(id);
    }

    public List<Professor> buscarPorNomeOuEspecialidade(String nome, String especialidade) {
        return professorRepository.findByNomeStartingWithOrEspecialidadeStartingWith(nome, especialidade);
    }

    public List<Professor> buscarPorEmailExato(String email) {
        return professorRepository.findByEmail(email);
    }

    public List<Professor> buscarPorEmailNaoGmail() {
        return professorRepository.findByEmailNotContaining("@gmail.com");
    }
}
