package app.service;

import app.entity.Curso;
import app.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    public Curso salvarCurso(Curso curso) {
        return cursoRepository.save(curso);
    }

    public List<Curso> buscarTodos() {
        return cursoRepository.findAll();
    }

    public Curso buscarPorId(Long id) {
        Optional<Curso> curso = cursoRepository.findById(id);
        if (curso.isEmpty()) {
            throw new RuntimeException("Curso não encontrado!");
        }
        return curso.get();
    }

    public Curso atualizarCurso(Curso curso) {
        return salvarCurso(curso);
    }

    public void excluirCurso(Long id) {
        if (!cursoRepository.existsById(id)) {
            throw new RuntimeException("Curso não encontrado para exclusão!");
        }
        cursoRepository.deleteById(id);
    }

    public List<Curso> buscarPorNome(String nome) {
        return cursoRepository.findByNomeContaining(nome);
    }
}
