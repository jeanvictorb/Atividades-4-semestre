package app.repository;

import app.entity.Professor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProfessorRepository extends JpaRepository<Professor, Long> {
    boolean existsByEmail(String email);

    List<Professor> findByNomeStartingWithOrEspecialidadeStartingWith(String nome, String especialidade);

    List<Professor> findByEmail(String email);

    List<Professor> findByEmailNotContaining(String email);
}
