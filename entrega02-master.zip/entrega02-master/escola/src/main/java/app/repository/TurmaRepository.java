package app.repository;

import app.entity.Turma;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TurmaRepository extends JpaRepository<Turma, Long> {
    List<Turma> findByAnoBetween(int anoInicio, int anoFim);

    List<Turma> findBySemestreAndAno(String semestre, int ano);

    List<Turma> findByNomeAndTurno(String nome, String turno);

    List<Turma> findByCursoNome(String nomeCurso);
}
